import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Menu, X, ChevronDown, Leaf } from 'lucide-react';

const languages = [
  { code: 'es', label: 'Español', flag: 'ES' },
  { code: 'en', label: 'English', flag: 'EN' },
  { code: 'de', label: 'Deutsch', flag: 'DE' },
  { code: 'fr', label: 'Français', flag: 'FR' },
  { code: 'pt', label: 'Português', flag: 'PT' },
];

const Navbar: React.FC = () => {
  const { t, i18n } = useTranslation();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [langOpen, setLangOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 100);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setMobileOpen(false);
    }
  };

  const changeLanguage = (lang: string) => {
    i18n.changeLanguage(lang);
    setLangOpen(false);
  };

  const currentLang = languages.find((l) => l.code === i18n.language) || languages[0];

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-[1000] transition-all duration-300 ${
        scrolled
          ? 'bg-white/95 backdrop-blur-sm shadow-[0_2px_20px_rgba(0,0,0,0.08)]'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-[1200px] mx-auto px-5 md:px-10">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <button
            onClick={() => scrollToSection('hero')}
            className="flex items-center gap-2 group"
          >
            <Leaf className="w-7 h-7 text-[#3A6B5F] transition-transform group-hover:scale-110" />
            <span className="font-['Cormorant_Garamond'] text-xl md:text-2xl font-light text-[#2C3E33]">
              Ahorra<span className="font-medium">Inteligente</span>
            </span>
          </button>

          {/* Desktop Nav */}
          <div className="hidden lg:flex items-center gap-8">
            <button
              onClick={() => scrollToSection('hero')}
              className="text-sm font-medium text-[#2C3E33] hover:text-[#3A6B5F] transition-colors"
            >
              {t('nav.home')}
            </button>
            <button
              onClick={() => scrollToSection('categories')}
              className="text-sm font-medium text-[#2C3E33] hover:text-[#3A6B5F] transition-colors"
            >
              {t('nav.categories')}
            </button>
            <button
              onClick={() => scrollToSection('articles')}
              className="text-sm font-medium text-[#2C3E33] hover:text-[#3A6B5F] transition-colors"
            >
              {t('nav.articles')}
            </button>
            <button
              onClick={() => scrollToSection('newsletter')}
              className="text-sm font-medium text-[#2C3E33] hover:text-[#3A6B5F] transition-colors"
            >
              {t('nav.newsletter')}
            </button>
            <button
              onClick={() => scrollToSection('contact')}
              className="text-sm font-medium text-[#2C3E33] hover:text-[#3A6B5F] transition-colors"
            >
              {t('nav.contact')}
            </button>
          </div>

          {/* Right side */}
          <div className="hidden lg:flex items-center gap-4">
            {/* Language selector */}
            <div className="relative">
              <button
                onClick={() => setLangOpen(!langOpen)}
                className="flex items-center gap-1.5 text-sm font-medium text-[#2C3E33] hover:text-[#3A6B5F] transition-colors px-3 py-1.5 rounded-md hover:bg-[#E8F0EC]"
              >
                <span className="text-xs font-bold">{currentLang.flag}</span>
                <span>{currentLang.label}</span>
                <ChevronDown className={`w-4 h-4 transition-transform ${langOpen ? 'rotate-180' : ''}`} />
              </button>
              {langOpen && (
                <div className="absolute top-full right-0 mt-1 bg-white rounded-lg shadow-lg border border-[#E8F0EC] py-1 min-w-[160px]">
                  {languages.map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => changeLanguage(lang.code)}
                      className={`w-full flex items-center gap-2 px-4 py-2 text-sm hover:bg-[#E8F0EC] transition-colors ${
                        lang.code === currentLang.code ? 'text-[#3A6B5F] font-medium' : 'text-[#2C3E33]'
                      }`}
                    >
                      <span className="text-xs font-bold">{lang.flag}</span>
                      {lang.label}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <button
              onClick={() => scrollToSection('hero')}
              className="bg-[#3A6B5F] text-white text-xs font-medium uppercase tracking-[0.08em] px-6 py-3 rounded hover:bg-[#D4A843] transition-colors duration-300"
            >
              {t('nav.startSaving')}
            </button>
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="lg:hidden p-2 text-[#2C3E33]"
          >
            {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile menu */}
        {mobileOpen && (
          <div className="lg:hidden bg-white/95 backdrop-blur-sm border-t border-[#E8F0EC] pb-6">
            <div className="flex flex-col gap-2 pt-4">
              {[
                { id: 'hero', label: t('nav.home') },
                { id: 'categories', label: t('nav.categories') },
                { id: 'articles', label: t('nav.articles') },
                { id: 'newsletter', label: t('nav.newsletter') },
                { id: 'contact', label: t('nav.contact') },
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className="text-left px-4 py-3 text-sm font-medium text-[#2C3E33] hover:text-[#3A6B5F] hover:bg-[#E8F0EC] rounded-lg transition-colors"
                >
                  {item.label}
                </button>
              ))}
            </div>
            <div className="mt-4 px-4">
              <p className="text-xs font-medium text-[#2C3E33]/50 mb-2 uppercase tracking-wider">
                Language / Idioma
              </p>
              <div className="flex flex-wrap gap-2">
                {languages.map((lang) => (
                  <button
                    key={lang.code}
                    onClick={() => changeLanguage(lang.code)}
                    className={`px-3 py-1.5 text-xs rounded-full border transition-colors ${
                      lang.code === currentLang.code
                        ? 'bg-[#3A6B5F] text-white border-[#3A6B5F]'
                        : 'text-[#2C3E33] border-[#E8F0EC] hover:border-[#3A6B5F]'
                    }`}
                  >
                    {lang.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
