import React from 'react';

interface IconProps {
  className?: string;
  size?: number;
}

export const IconHogar: React.FC<IconProps> = ({ className = '', size = 80 }) => (
  <svg width={size} height={size} viewBox="0 0 80 80" fill="none" className={className}>
    <path
      d="M40 12L12 36H20V64H32V48H48V64H60V36H68L40 12Z"
      stroke="currentColor"
      strokeWidth="2.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      fill="none"
    />
    <rect x="32" y="48" width="16" height="16" rx="1" stroke="currentColor" strokeWidth="2" fill="none" />
    <rect x="34" y="38" width="6" height="6" rx="1" stroke="currentColor" strokeWidth="1.5" fill="none" />
    <rect x="42" y="38" width="6" height="6" rx="1" stroke="currentColor" strokeWidth="1.5" fill="none" />
  </svg>
);

export const IconSupermercado: React.FC<IconProps> = ({ className = '', size = 80 }) => (
  <svg width={size} height={size} viewBox="0 0 80 80" fill="none" className={className}>
    <path
      d="M20 24H16L12 52H56L60 24H56"
      stroke="currentColor"
      strokeWidth="2.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      fill="none"
    />
    <path
      d="M20 24V20C20 16.6863 22.6863 14 26 14H34"
      stroke="currentColor"
      strokeWidth="2.5"
      strokeLinecap="round"
      fill="none"
    />
    <path
      d="M40 32C40 32 42 28 46 28C50 28 50 32 50 34C50 36 48 38 46 38"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      fill="none"
    />
    <path
      d="M46 38C46 38 48 42 44 42C40 42 40 38 40 36C40 34 42 32 44 32"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      fill="none"
    />
    <circle cx="24" cy="60" r="3" stroke="currentColor" strokeWidth="2" fill="none" />
    <circle cx="48" cy="60" r="3" stroke="currentColor" strokeWidth="2" fill="none" />
  </svg>
);

export const IconTransporte: React.FC<IconProps> = ({ className = '', size = 80 }) => (
  <svg width={size} height={size} viewBox="0 0 80 80" fill="none" className={className}>
    <circle cx="24" cy="52" r="8" stroke="currentColor" strokeWidth="2.5" fill="none" />
    <circle cx="56" cy="52" r="8" stroke="currentColor" strokeWidth="2.5" fill="none" />
    <path
      d="M16 52H8L12 28H56L60 52H64"
      stroke="currentColor"
      strokeWidth="2.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      fill="none"
    />
    <path
      d="M12 28L18 20H50L56 28"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      fill="none"
    />
    <path
      d="M36 36V44"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
    />
    <path
      d="M32 40H40"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
    />
    <path
      d="M28 20V16H40V20"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      fill="none"
    />
  </svg>
);

export const IconOcio: React.FC<IconProps> = ({ className = '', size = 80 }) => (
  <svg width={size} height={size} viewBox="0 0 80 80" fill="none" className={className}>
    <path
      d="M28 16H52C54.2091 16 56 17.7909 56 20V56C56 58.2091 54.2091 60 52 60H28C25.7909 60 24 58.2091 24 56V20C24 17.7909 25.7909 16 28 16Z"
      stroke="currentColor"
      strokeWidth="2.5"
      fill="none"
    />
    <path
      d="M32 24H48"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
    />
    <path
      d="M32 32H44"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
    />
    <path
      d="M32 40H42"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
    />
    <path
      d="M60 24H66C67.1046 24 68 24.8954 68 26V54C68 55.1046 67.1046 56 66 56H60"
      stroke="currentColor"
      strokeWidth="2.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      fill="none"
    />
    <path
      d="M60 60V64"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
    />
    <circle cx="60" cy="68" r="2" fill="currentColor" />
  </svg>
);

export const IconFamilia: React.FC<IconProps> = ({ className = '', size = 80 }) => (
  <svg width={size} height={size} viewBox="0 0 80 80" fill="none" className={className}>
    <circle cx="28" cy="24" r="8" stroke="currentColor" strokeWidth="2.5" fill="none" />
    <circle cx="52" cy="24" r="8" stroke="currentColor" strokeWidth="2.5" fill="none" />
    <circle cx="40" cy="18" r="5" stroke="currentColor" strokeWidth="2.5" fill="none" />
    <path
      d="M16 56V46C16 42.6863 18.6863 40 22 40H26"
      stroke="currentColor"
      strokeWidth="2.5"
      strokeLinecap="round"
      fill="none"
    />
    <path
      d="M64 56V46C64 42.6863 61.3137 40 58 40H54"
      stroke="currentColor"
      strokeWidth="2.5"
      strokeLinecap="round"
      fill="none"
    />
    <path
      d="M28 40V56"
      stroke="currentColor"
      strokeWidth="2.5"
      strokeLinecap="round"
    />
    <path
      d="M52 40V56"
      stroke="currentColor"
      strokeWidth="2.5"
      strokeLinecap="round"
    />
    <path
      d="M40 32V56"
      stroke="currentColor"
      strokeWidth="2.5"
      strokeLinecap="round"
    />
    <path
      d="M36 56H44"
      stroke="currentColor"
      strokeWidth="2.5"
      strokeLinecap="round"
    />
    <path
      d="M40 8C40 8 34 4 28 8C28 8 30 2 40 2C50 2 52 8 52 8C46 4 40 8 40 8Z"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      fill="none"
    />
  </svg>
);

export const IconFinanzas: React.FC<IconProps> = ({ className = '', size = 80 }) => (
  <svg width={size} height={size} viewBox="0 0 80 80" fill="none" className={className}>
    <ellipse cx="40" cy="44" rx="28" ry="22" stroke="currentColor" strokeWidth="2.5" fill="none" />
    <ellipse cx="40" cy="40" rx="28" ry="22" stroke="currentColor" strokeWidth="2.5" fill="none" />
    <path
      d="M40 28V32"
      stroke="currentColor"
      strokeWidth="2.5"
      strokeLinecap="round"
    />
    <path
      d="M40 48V52"
      stroke="currentColor"
      strokeWidth="2.5"
      strokeLinecap="round"
    />
    <path
      d="M36 36C36 36 38 32 42 34C46 36 44 40 40 40C36 40 34 44 38 46C42 48 44 44 44 44"
      stroke="currentColor"
      strokeWidth="2.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      fill="none"
    />
    <path
      d="M28 18C28 18 32 12 40 12C48 12 52 18 52 18"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      fill="none"
    />
    <circle cx="40" cy="10" r="3" stroke="currentColor" strokeWidth="2" fill="none" />
  </svg>
);
