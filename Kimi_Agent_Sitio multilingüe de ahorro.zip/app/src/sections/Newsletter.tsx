import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useScrollReveal } from '../hooks/useScrollReveal';
import { Check } from 'lucide-react';

const Newsletter: React.FC = () => {
  const { t } = useTranslation();
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const { ref, isVisible } = useScrollReveal<HTMLElement>();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim()) {
      setSubmitted(true);
      setEmail('');
    }
  };

  return (
    <section
      id="newsletter"
      ref={ref}
      className="relative w-full py-24 md:py-32 overflow-hidden"
    >
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="/images/newsletter-bg.jpg"
          alt=""
          className="w-full h-full object-cover opacity-30"
        />
      </div>

      {/* Gradient Overlay */}
      <div
        className="absolute inset-0"
        style={{
          background:
            'linear-gradient(to right, rgba(245,241,235,0.95), rgba(232,240,236,0.92))',
        }}
      />

      {/* Content */}
      <div
        className={`relative z-10 max-w-[600px] mx-auto px-5 md:px-10 text-center transition-all duration-600 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        }`}
      >
        <p className="text-xs font-medium uppercase tracking-[0.12em] text-[#3A6B5F] mb-4">
          {t('newsletter.label')}
        </p>
        <h2 className="font-['Cormorant_Garamond'] text-3xl md:text-4xl lg:text-5xl font-normal leading-[1.15] tracking-[-0.01em] text-[#2C3E33] mb-4">
          {t('newsletter.title')}
        </h2>
        <p className="text-base md:text-lg text-[#2C3E33]/80 leading-relaxed mb-8 max-w-[480px] mx-auto">
          {t('newsletter.description')}
        </p>

        {submitted ? (
          <div className="flex items-center justify-center gap-2 text-[#3A6B5F]">
            <div className="w-8 h-8 rounded-full bg-[#3A6B5F] flex items-center justify-center">
              <Check className="w-5 h-5 text-white" />
            </div>
            <span className="font-medium">{t('newsletter.success')}</span>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3 max-w-[440px] mx-auto">
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder={t('newsletter.placeholder')}
              required
              className="flex-1 px-5 py-4 border border-[#8FB8A1] rounded text-sm text-[#2C3E33] placeholder:text-[#2C3E33]/40 focus:outline-none focus:ring-2 focus:ring-[#3A6B5F] focus:border-transparent bg-white/80"
            />
            <button
              type="submit"
              className="bg-[#3A6B5F] text-white text-xs font-medium uppercase tracking-[0.08em] px-8 py-4 rounded hover:bg-[#D4A843] transition-colors duration-300 whitespace-nowrap"
            >
              {t('newsletter.button')}
            </button>
          </form>
        )}

        <p className="text-xs text-[#2C3E33]/50 mt-4">
          {t('newsletter.privacy')}
        </p>
      </div>
    </section>
  );
};

export default Newsletter;
