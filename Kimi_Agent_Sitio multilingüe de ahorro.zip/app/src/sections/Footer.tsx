import React from 'react';
import { useTranslation } from 'react-i18next';
import { Link } from 'react-router';
import { Leaf, Instagram, Twitter, Facebook } from 'lucide-react';

const Footer: React.FC = () => {
  const { t } = useTranslation();

  const categoryLinks = [
    t('categories.home.title'),
    t('categories.supermarket.title'),
    t('categories.transport.title'),
    t('categories.leisure.title'),
    t('categories.family.title'),
    t('categories.finance.title'),
  ];

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <footer className="w-full bg-[#2C3E33] pt-14 md:pt-16 pb-8">
      <div className="max-w-[1200px] mx-auto px-5 md:px-10">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10 lg:gap-8 mb-10">
          {/* Logo + Description */}
          <div className="sm:col-span-2 lg:col-span-1">
            <Link to="/" className="inline-flex items-center gap-2 mb-4 group">
              <Leaf className="w-6 h-6 text-white/80 group-hover:text-[#8FB8A1] transition-colors" />
              <span className="font-['Cormorant_Garamond'] text-xl font-light text-white/90">
                Ahorra<span className="font-medium">Inteligente</span>
              </span>
            </Link>
            <p className="text-sm text-white/60 leading-relaxed">
              {t('footer.description')}
            </p>
          </div>

          {/* Categories */}
          <div>
            <h4 className="text-xs font-medium uppercase tracking-[0.12em] text-white/50 mb-4">
              {t('footer.categories')}
            </h4>
            <ul className="space-y-2.5">
              {categoryLinks.map((link, index) => (
                <li key={index}>
                  <button
                    onClick={() => scrollToSection('categories')}
                    className="text-sm text-white/60 hover:text-white transition-colors duration-200"
                  >
                    {link}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h4 className="text-xs font-medium uppercase tracking-[0.12em] text-white/50 mb-4">
              {t('footer.legal')}
            </h4>
            <ul className="space-y-2.5">
              <li>
                <Link
                  to="/privacidad"
                  className="text-sm text-white/60 hover:text-white transition-colors duration-200"
                >
                  {t('footer.privacy')}
                </Link>
              </li>
              <li>
                <Link
                  to="/terminos"
                  className="text-sm text-white/60 hover:text-white transition-colors duration-200"
                >
                  {t('footer.terms')}
                </Link>
              </li>
              <li>
                <Link
                  to="/cookies"
                  className="text-sm text-white/60 hover:text-white transition-colors duration-200"
                >
                  {t('footer.cookies')}
                </Link>
              </li>
            </ul>
          </div>

          {/* Social */}
          <div>
            <h4 className="text-xs font-medium uppercase tracking-[0.12em] text-white/50 mb-4">
              Social
            </h4>
            <div className="flex gap-3">
              {[Instagram, Twitter, Facebook].map((Icon, index) => (
                <button
                  key={index}
                  className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center text-white/50 hover:bg-white/20 hover:text-white transition-all duration-200"
                >
                  <Icon className="w-4 h-4" />
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-white/10 pt-6">
          <p className="text-xs text-white/40 text-center">
            {t('footer.copyright')}
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
