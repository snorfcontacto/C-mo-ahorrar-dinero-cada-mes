import React, { useEffect, useState, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { useScrollReveal } from '../hooks/useScrollReveal';

interface StatItemProps {
  value: string;
  label: string;
  delay: number;
  isVisible: boolean;
}

const StatItem: React.FC<StatItemProps> = ({ value, label, delay, isVisible }) => {
  const [displayValue, setDisplayValue] = useState('0');
  const hasAnimated = useRef(false);

  useEffect(() => {
    if (!isVisible || hasAnimated.current) return;
    hasAnimated.current = true;

    const timeout = setTimeout(() => {
      const numericMatch = value.match(/[\d,]+/);
      if (!numericMatch) {
        setDisplayValue(value);
        return;
      }

      const target = parseInt(numericMatch[0].replace(/,/g, ''), 10);
      const prefix = value.match(/^[^\d]*/)?.[0] || '';
      const suffix = value.match(/[^\d]*$/)?.[0] || '';
      const duration = 2000;
      const startTime = performance.now();

      const animate = (currentTime: number) => {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        const easeOut = 1 - Math.pow(1 - progress, 3);
        const current = Math.floor(easeOut * target);

        if (target >= 1000) {
          setDisplayValue(`${prefix}${current.toLocaleString()}${suffix}`);
        } else {
          setDisplayValue(`${prefix}${current}${suffix}`);
        }

        if (progress < 1) {
          requestAnimationFrame(animate);
        } else {
          setDisplayValue(value);
        }
      };

      requestAnimationFrame(animate);
    }, delay);

    return () => clearTimeout(timeout);
  }, [isVisible, value, delay]);

  return (
    <div
      className={`text-center transition-all duration-600 ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
      }`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      <p className="font-['Cormorant_Garamond'] text-[48px] md:text-[56px] lg:text-[72px] font-light leading-none tracking-[-0.02em] text-[#D4A843]">
        {displayValue}
      </p>
      <p className="text-sm md:text-base text-[#2C3E33] mt-3 font-normal">
        {label}
      </p>
    </div>
  );
};

const Stats: React.FC = () => {
  const { t } = useTranslation();
  const { ref, isVisible } = useScrollReveal<HTMLElement>({ threshold: 0.3 });

  const stats = [
    { value: t('stats.reduction'), label: t('stats.reductionLabel') },
    { value: t('stats.savings'), label: t('stats.savingsLabel') },
    { value: t('stats.readers'), label: t('stats.readersLabel') },
    { value: t('stats.tips'), label: t('stats.tipsLabel') },
  ];

  return (
    <section ref={ref} className="w-full py-16 md:py-20 bg-[#E8F0EC]">
      <div className="max-w-[1200px] mx-auto px-5 md:px-10">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 md:gap-10">
          {stats.map((stat, index) => (
            <StatItem
              key={index}
              value={stat.value}
              label={stat.label}
              delay={index * 100}
              isVisible={isVisible}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Stats;
