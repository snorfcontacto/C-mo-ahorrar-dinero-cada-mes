import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useScrollReveal } from '../hooks/useScrollReveal';
import { Mail, MapPin, Instagram, Twitter, Facebook } from 'lucide-react';

const Contact: React.FC = () => {
  const { t } = useTranslation();
  const { ref: infoRef, isVisible: infoVisible } = useScrollReveal<HTMLDivElement>();
  const { ref: formRef, isVisible: formVisible } = useScrollReveal<HTMLDivElement>();
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <section id="contact" className="w-full py-20 md:py-28 bg-[#F5F1EB]">
      <div className="max-w-[1200px] mx-auto px-5 md:px-10">
        {/* Header */}
        <div className="text-center mb-12 md:mb-16">
          <p className="text-xs font-medium uppercase tracking-[0.12em] text-[#3A6B5F] mb-4">
            {t('contact.label')}
          </p>
          <h2 className="font-['Cormorant_Garamond'] text-3xl md:text-4xl lg:text-5xl font-normal leading-[1.15] tracking-[-0.01em] text-[#2C3E33]">
            {t('contact.title')}
          </h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16">
          {/* Info Column */}
          <div
            ref={infoRef}
            className={`transition-all duration-600 ${
              infoVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-5'
            }`}
          >
            <p className="text-base md:text-lg text-[#2C3E33]/80 leading-relaxed mb-8">
              {t('contact.description')}
            </p>

            <div className="space-y-5 mb-8">
              <div className="flex items-center gap-3 text-[#2C3E33]">
                <div className="w-10 h-10 rounded-full bg-[#E8F0EC] flex items-center justify-center">
                  <Mail className="w-5 h-5 text-[#3A6B5F]" />
                </div>
                <span className="text-sm">{t('contact.email')}</span>
              </div>
              <div className="flex items-center gap-3 text-[#2C3E33]">
                <div className="w-10 h-10 rounded-full bg-[#E8F0EC] flex items-center justify-center">
                  <MapPin className="w-5 h-5 text-[#3A6B5F]" />
                </div>
                <span className="text-sm">{t('contact.location')}</span>
              </div>
            </div>

            {/* Social Links */}
            <div>
              <p className="text-xs font-medium uppercase tracking-[0.12em] text-[#2C3E33]/50 mb-3">
                Social
              </p>
              <div className="flex gap-3">
                {[Instagram, Twitter, Facebook].map((Icon, index) => (
                  <button
                    key={index}
                    className="w-10 h-10 rounded-full bg-[#E8F0EC] flex items-center justify-center text-[#3A6B5F] hover:bg-[#3A6B5F] hover:text-white transition-colors duration-300"
                  >
                    <Icon className="w-5 h-5" />
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Form Column */}
          <div
            ref={formRef}
            className={`transition-all duration-600 ${
              formVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-5'
            }`}
          >
            {submitted ? (
              <div className="bg-[#E8F0EC] rounded-lg p-8 text-center">
                <div className="w-12 h-12 rounded-full bg-[#3A6B5F] flex items-center justify-center mx-auto mb-4">
                  <Mail className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-['Cormorant_Garamond'] text-xl font-medium text-[#2C3E33] mb-2">
                  {t('contact.form.success')}
                </h3>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-5">
                <div>
                  <input
                    type="text"
                    placeholder={t('contact.form.name')}
                    required
                    className="w-full px-5 py-4 border border-[#8FB8A1] rounded text-sm text-[#2C3E33] placeholder:text-[#2C3E33]/40 focus:outline-none focus:ring-2 focus:ring-[#3A6B5F] focus:border-transparent bg-white/80"
                  />
                </div>
                <div>
                  <input
                    type="email"
                    placeholder={t('contact.form.email')}
                    required
                    className="w-full px-5 py-4 border border-[#8FB8A1] rounded text-sm text-[#2C3E33] placeholder:text-[#2C3E33]/40 focus:outline-none focus:ring-2 focus:ring-[#3A6B5F] focus:border-transparent bg-white/80"
                  />
                </div>
                <div>
                  <select
                    className="w-full px-5 py-4 border border-[#8FB8A1] rounded text-sm text-[#2C3E33] focus:outline-none focus:ring-2 focus:ring-[#3A6B5F] focus:border-transparent bg-white/80 appearance-none cursor-pointer"
                  >
                    <option value="general">{t('contact.form.subjects.general')}</option>
                    <option value="suggestion">{t('contact.form.subjects.suggestion')}</option>
                    <option value="collab">{t('contact.form.subjects.collab')}</option>
                    <option value="other">{t('contact.form.subjects.other')}</option>
                  </select>
                </div>
                <div>
                  <textarea
                    placeholder={t('contact.form.message')}
                    required
                    rows={5}
                    className="w-full px-5 py-4 border border-[#8FB8A1] rounded text-sm text-[#2C3E33] placeholder:text-[#2C3E33]/40 focus:outline-none focus:ring-2 focus:ring-[#3A6B5F] focus:border-transparent bg-white/80 resize-none"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full bg-[#3A6B5F] text-white text-xs font-medium uppercase tracking-[0.08em] px-8 py-4 rounded hover:bg-[#D4A843] transition-colors duration-300"
                >
                  {t('contact.form.submit')}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
