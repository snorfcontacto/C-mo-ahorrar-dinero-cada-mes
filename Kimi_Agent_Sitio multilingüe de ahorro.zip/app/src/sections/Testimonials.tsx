import React, { useState, useEffect, useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import { useScrollReveal } from '../hooks/useScrollReveal';

const testimonialAvatars = [
  '/images/avatar-1.jpg',
  '/images/avatar-2.jpg',
  '/images/avatar-3.jpg',
];

const Testimonials: React.FC = () => {
  const { t } = useTranslation();
  const [currentSlide, setCurrentSlide] = useState(0);
  const { ref, isVisible } = useScrollReveal<HTMLElement>();

  const testimonialKeys = ['1', '2', '3'];

  const nextSlide = useCallback(() => {
    setCurrentSlide((prev) => (prev + 1) % testimonialKeys.length);
  }, [testimonialKeys.length]);

  useEffect(() => {
    const interval = setInterval(nextSlide, 5000);
    return () => clearInterval(interval);
  }, [nextSlide]);

  return (
    <section ref={ref} className="w-full py-20 md:py-28 bg-[#E8F0EC]">
      <div className="max-w-[800px] mx-auto px-5 md:px-10 text-center">
        {/* Header */}
        <div
          className={`mb-12 md:mb-16 transition-all duration-600 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <p className="text-xs font-medium uppercase tracking-[0.12em] text-[#3A6B5F] mb-4">
            {t('testimonials.label')}
          </p>
          <h2 className="font-['Cormorant_Garamond'] text-3xl md:text-4xl lg:text-5xl font-normal leading-[1.15] tracking-[-0.01em] text-[#2C3E33]">
            {t('testimonials.title')}
          </h2>
        </div>

        {/* Carousel */}
        <div className="relative min-h-[280px] md:min-h-[240px]">
          {testimonialKeys.map((key, index) => (
            <div
              key={key}
              className={`absolute inset-0 flex flex-col items-center transition-opacity duration-500 ${
                index === currentSlide ? 'opacity-100 z-10' : 'opacity-0 z-0'
              }`}
            >
              {/* Avatar */}
              <div className="w-16 h-16 md:w-20 md:h-20 rounded-full overflow-hidden mb-6 ring-4 ring-white shadow-lg">
                <img
                  src={testimonialAvatars[index]}
                  alt={t(`testimonials.items.${key}.name`)}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Quote */}
              <blockquote className="text-base md:text-lg text-[#2C3E33] leading-relaxed italic mb-6 max-w-[600px]">
                &ldquo;{t(`testimonials.items.${key}.text`)}&rdquo;
              </blockquote>

              {/* Author */}
              <div>
                <p className="text-sm font-semibold text-[#2C3E33]">
                  {t(`testimonials.items.${key}.name`)}
                </p>
                <p className="text-xs text-[#2C3E33]/60 mt-1">
                  {t(`testimonials.items.${key}.location`)}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Dots */}
        <div className="flex justify-center gap-2 mt-8">
          {testimonialKeys.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`w-2 h-2 rounded-full transition-all duration-300 ${
                index === currentSlide
                  ? 'bg-[#3A6B5F] w-6'
                  : 'bg-[#2C3E33]/30 hover:bg-[#2C3E33]/50'
              }`}
              aria-label={`Go to testimonial ${index + 1}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
