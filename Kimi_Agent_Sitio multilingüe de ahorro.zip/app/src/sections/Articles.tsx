import React from 'react';
import { useTranslation } from 'react-i18next';
import { useScrollReveal } from '../hooks/useScrollReveal';
import { Clock } from 'lucide-react';

const articleImages = [
  '/images/articulo-1.jpg',
  '/images/articulo-2.jpg',
  '/images/articulo-3.jpg',
  '/images/articulo-4.jpg',
  '/images/articulo-5.jpg',
  '/images/articulo-6.jpg',
];

const articleKeys = ['1', '2', '3', '4', '5', '6'];

const Articles: React.FC = () => {
  const { t } = useTranslation();
  const { ref: headerRef, isVisible: headerVisible } = useScrollReveal<HTMLDivElement>();
  const { ref: gridRef, isVisible: gridVisible } = useScrollReveal<HTMLDivElement>();

  return (
    <section id="articles" className="w-full py-20 md:py-28 bg-[#E8F0EC]">
      <div className="max-w-[1200px] mx-auto px-5 md:px-10">
        {/* Header */}
        <div
          ref={headerRef}
          className={`flex flex-col md:flex-row md:items-end md:justify-between mb-12 md:mb-16 gap-4 transition-all duration-600 ${
            headerVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <div>
            <p className="text-xs font-medium uppercase tracking-[0.12em] text-[#3A6B5F] mb-4">
              {t('articles.label')}
            </p>
            <h2 className="font-['Cormorant_Garamond'] text-3xl md:text-4xl lg:text-5xl font-normal leading-[1.15] tracking-[-0.01em] text-[#2C3E33]">
              {t('articles.title')}
            </h2>
          </div>
          <button className="text-sm font-medium text-[#3A6B5F] hover:text-[#D4A843] transition-colors self-start md:self-auto">
            {t('articles.viewAll')}
          </button>
        </div>

        {/* Grid */}
        <div
          ref={gridRef}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8"
        >
          {articleKeys.map((key, index) => (
            <article
              key={key}
              className={`group bg-white rounded-lg overflow-hidden shadow-[0_4px_20px_rgba(44,62,51,0.08)] hover:shadow-[0_8px_30px_rgba(44,62,51,0.12)] transition-all duration-500 cursor-pointer ${
                gridVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{
                transitionDelay: gridVisible ? `${index * 80}ms` : '0ms',
              }}
            >
              {/* Image */}
              <div className="relative overflow-hidden aspect-[16/9]">
                <img
                  src={articleImages[index]}
                  alt={t(`articles.featured.${key}.title`)}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
              </div>

              {/* Content */}
              <div className="p-6">
                <span className="inline-block bg-[#D4A843] text-white text-[11px] font-medium uppercase tracking-wider px-3 py-1 rounded-full mb-3">
                  {t(`articles.featured.${key}.badge`)}
                </span>
                <h3 className="font-['Cormorant_Garamond'] text-xl md:text-[22px] font-medium text-[#2C3E33] leading-tight mb-3 group-hover:text-[#3A6B5F] transition-colors">
                  {t(`articles.featured.${key}.title`)}
                </h3>
                <p className="text-sm text-[#2C3E33]/70 leading-relaxed mb-4">
                  {t(`articles.featured.${key}.excerpt`)}
                </p>
                <div className="flex items-center gap-1.5 text-xs text-[#2C3E33]/50">
                  <Clock className="w-3.5 h-3.5" />
                  <span>
                    {t(`articles.featured.${key}.readTime`)} {t('articles.readTime')}
                  </span>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Articles;
