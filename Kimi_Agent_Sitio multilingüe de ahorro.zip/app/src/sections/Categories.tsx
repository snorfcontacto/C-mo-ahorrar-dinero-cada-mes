import React from 'react';
import { useTranslation } from 'react-i18next';
import { useScrollReveal } from '../hooks/useScrollReveal';
import {
  IconHogar,
  IconSupermercado,
  IconTransporte,
  IconOcio,
  IconFamilia,
  IconFinanzas,
} from '../components/icons/CategoryIcons';

const categoryIcons = [
  IconHogar,
  IconSupermercado,
  IconTransporte,
  IconOcio,
  IconFamilia,
  IconFinanzas,
];

const categoryKeys = ['home', 'supermarket', 'transport', 'leisure', 'family', 'finance'];

const Categories: React.FC = () => {
  const { t } = useTranslation();
  const { ref: headerRef, isVisible: headerVisible } = useScrollReveal<HTMLDivElement>();
  const { ref: gridRef, isVisible: gridVisible } = useScrollReveal<HTMLDivElement>();

  return (
    <section id="categories" className="w-full py-20 md:py-28 bg-[#F5F1EB]">
      <div className="max-w-[1200px] mx-auto px-5 md:px-10">
        {/* Header */}
        <div
          ref={headerRef}
          className={`text-center mb-12 md:mb-16 transition-all duration-600 ${
            headerVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <p className="text-xs font-medium uppercase tracking-[0.12em] text-[#3A6B5F] mb-4">
            {t('categories.label')}
          </p>
          <h2 className="font-['Cormorant_Garamond'] text-3xl md:text-4xl lg:text-5xl font-normal leading-[1.15] tracking-[-0.01em] text-[#2C3E33] max-w-[600px] mx-auto">
            {t('categories.title')}
          </h2>
        </div>

        {/* Grid */}
        <div
          ref={gridRef}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {categoryKeys.map((key, index) => {
            const Icon = categoryIcons[index];
            return (
              <div
                key={key}
                className={`group bg-[#E8F0EC] rounded-xl p-8 md:p-10 text-center cursor-pointer transition-all duration-300 hover:bg-[#8FB8A1] hover:shadow-lg ${
                  gridVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                }`}
                style={{
                  transitionDelay: gridVisible ? `${index * 80}ms` : '0ms',
                  transitionDuration: '600ms',
                }}
              >
                <div className="flex justify-center mb-5 text-[#3A6B5F] group-hover:text-white transition-colors duration-300">
                  <Icon size={64} />
                </div>
                <h3 className="font-['Cormorant_Garamond'] text-xl md:text-2xl font-medium text-[#2C3E33] group-hover:text-white transition-colors duration-300 mb-3">
                  {t(`categories.${key}.title`)}
                </h3>
                <p className="text-sm text-[#2C3E33]/70 group-hover:text-white/90 transition-colors duration-300 leading-relaxed">
                  {t(`categories.${key}.description`)}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Categories;
