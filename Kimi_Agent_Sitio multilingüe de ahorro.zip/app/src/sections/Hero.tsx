import React from 'react';
import { useTranslation } from 'react-i18next';
import { ChevronDown } from 'lucide-react';

const Hero: React.FC = () => {
  const { t } = useTranslation();

  const scrollToArticles = () => {
    const element = document.getElementById('articles');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToCategories = () => {
    const element = document.getElementById('categories');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="hero"
      className="relative w-full min-h-[700px] h-screen overflow-hidden"
    >
      {/* Background Image with Ken Burns */}
      <div className="absolute inset-0 animate-ken-burns">
        <img
          src="/images/hero-ahorro.jpg"
          alt="Savings motivation"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Gradient Overlay */}
      <div
        className="absolute inset-0"
        style={{
          background:
            'linear-gradient(to right, rgba(245,241,235,0.97) 0%, rgba(245,241,235,0.85) 35%, rgba(245,241,235,0.4) 60%, transparent 100%)',
        }}
      />

      {/* Content */}
      <div className="relative z-10 flex items-center h-full max-w-[1200px] mx-auto px-5 md:px-10">
        <div className="max-w-[600px] pt-20">
          <p className="text-xs font-medium uppercase tracking-[0.12em] text-[#3A6B5F] mb-4 animate-fade-up" style={{ animationDelay: '200ms' }}>
            {t('hero.welcome')}
          </p>
          <h1
            className="font-['Cormorant_Garamond'] text-[42px] md:text-[56px] lg:text-[64px] font-light leading-[1.1] tracking-[-0.02em] text-[#2C3E33] mb-6 animate-fade-up"
            style={{ animationDelay: '400ms' }}
          >
            {t('hero.title')}
          </h1>
          <p
            className="text-base md:text-lg lg:text-xl text-[#2C3E33]/80 leading-[1.7] max-w-[480px] mb-10 animate-fade-up"
            style={{ animationDelay: '600ms' }}
          >
            {t('hero.subtitle')}
          </p>
          <div className="flex flex-wrap gap-4 animate-fade-up" style={{ animationDelay: '800ms' }}>
            <button
              onClick={scrollToCategories}
              className="bg-[#3A6B5F] text-white text-xs font-medium uppercase tracking-[0.08em] px-8 py-4 rounded hover:bg-[#D4A843] transition-colors duration-300"
            >
              {t('hero.ctaPrimary')}
            </button>
            <button
              onClick={scrollToArticles}
              className="border border-[#3A6B5F] text-[#3A6B5F] text-xs font-medium uppercase tracking-[0.08em] px-8 py-4 rounded hover:bg-[#3A6B5F] hover:text-white transition-colors duration-300"
            >
              {t('hero.ctaSecondary')}
            </button>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div
        className="absolute bottom-10 left-1/2 -translate-x-1/2 z-10 animate-fade-in animate-bounce-slow"
        style={{ animationDelay: '1200ms' }}
      >
        <button
          onClick={scrollToCategories}
          className="w-10 h-10 rounded-full border-2 border-[#3A6B5F] flex items-center justify-center text-[#3A6B5F] hover:bg-[#3A6B5F] hover:text-white transition-colors"
        >
          <ChevronDown className="w-5 h-5" />
        </button>
      </div>
    </section>
  );
};

export default Hero;
