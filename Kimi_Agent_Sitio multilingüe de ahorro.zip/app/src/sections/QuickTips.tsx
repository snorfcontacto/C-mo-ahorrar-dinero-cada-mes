import React from 'react';
import { useTranslation } from 'react-i18next';
import { useScrollReveal } from '../hooks/useScrollReveal';

const QuickTips: React.FC = () => {
  const { t } = useTranslation();
  const { ref: headerRef, isVisible: headerVisible } = useScrollReveal<HTMLDivElement>();
  const { ref: gridRef, isVisible: gridVisible } = useScrollReveal<HTMLDivElement>();

  const tips = [
    { key: 'tip1', number: t('quickTips.tip1.number') },
    { key: 'tip2', number: t('quickTips.tip2.number') },
    { key: 'tip3', number: t('quickTips.tip3.number') },
  ];

  return (
    <section className="w-full py-20 md:py-28 bg-[#F5F1EB]">
      <div className="max-w-[1200px] mx-auto px-5 md:px-10">
        {/* Header */}
        <div
          ref={headerRef}
          className={`text-center mb-12 md:mb-16 transition-all duration-600 ${
            headerVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <p className="text-xs font-medium uppercase tracking-[0.12em] text-[#3A6B5F] mb-4">
            {t('quickTips.label')}
          </p>
          <h2 className="font-['Cormorant_Garamond'] text-3xl md:text-4xl lg:text-5xl font-normal leading-[1.15] tracking-[-0.01em] text-[#2C3E33]">
            {t('quickTips.title')}
          </h2>
        </div>

        {/* Tips Grid */}
        <div
          ref={gridRef}
          className="grid grid-cols-1 md:grid-cols-3 gap-10 md:gap-12"
        >
          {tips.map((tip, index) => (
            <div
              key={tip.key}
              className={`text-center md:text-left transition-all duration-600 ${
                gridVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: `${index * 100}ms` }}
            >
              <p className="font-['Cormorant_Garamond'] text-4xl md:text-5xl lg:text-[56px] font-light text-[#D4A843] leading-none mb-4">
                {tip.number}
              </p>
              <h3 className="font-['Cormorant_Garamond'] text-xl md:text-2xl font-medium text-[#2C3E33] mb-3">
                {t(`quickTips.${tip.key}.title`)}
              </h3>
              <p className="text-sm md:text-base text-[#2C3E33]/70 leading-relaxed">
                {t(`quickTips.${tip.key}.description`)}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default QuickTips;
