import React from 'react';
import { useTranslation } from 'react-i18next';
import LegalPage from './LegalPage';

const CookiesPage: React.FC = () => {
  const { t } = useTranslation();

  const content = (
    <>
      <section>
        <h2 className="font-['Cormorant_Garamond'] text-2xl font-medium text-[#2C3E33] mb-4">
          {t('cookies.introTitle')}
        </h2>
        <p>{t('cookies.introText')}</p>
      </section>

      <section>
        <h2 className="font-['Cormorant_Garamond'] text-2xl font-medium text-[#2C3E33] mb-4">
          {t('cookies.whatAreTitle')}
        </h2>
        <p>{t('cookies.whatAreText')}</p>
      </section>

      <section>
        <h2 className="font-['Cormorant_Garamond'] text-2xl font-medium text-[#2C3E33] mb-4">
          {t('cookies.typesTitle')}
        </h2>
        <p>{t('cookies.typesIntro')}</p>
        <ul className="list-disc pl-6 space-y-1 mt-2">
          <li>{t('cookies.type1')}</li>
          <li>{t('cookies.type2')}</li>
          <li>{t('cookies.type3')}</li>
        </ul>
      </section>

      <section>
        <h2 className="font-['Cormorant_Garamond'] text-2xl font-medium text-[#2C3E33] mb-4">
          {t('cookies.usedTitle')}
        </h2>
        <p>{t('cookies.usedIntro')}</p>
        <ul className="list-disc pl-6 space-y-1 mt-2">
          <li>{t('cookies.used1')}</li>
          <li>{t('cookies.used2')}</li>
          <li>{t('cookies.used3')}</li>
        </ul>
      </section>

      <section>
        <h2 className="font-['Cormorant_Garamond'] text-2xl font-medium text-[#2C3E33] mb-4">
          {t('cookies.thirdPartyTitle')}
        </h2>
        <p>{t('cookies.thirdPartyText')}</p>
      </section>

      <section>
        <h2 className="font-['Cormorant_Garamond'] text-2xl font-medium text-[#2C3E33] mb-4">
          {t('cookies.manageTitle')}
        </h2>
        <p>{t('cookies.manageText')}</p>
        <ul className="list-disc pl-6 space-y-1 mt-2">
          <li>{t('cookies.manage1')}</li>
          <li>{t('cookies.manage2')}</li>
          <li>{t('cookies.manage3')}</li>
        </ul>
      </section>

      <section>
        <h2 className="font-['Cormorant_Garamond'] text-2xl font-medium text-[#2C3E33] mb-4">
          {t('cookies.consentTitle')}
        </h2>
        <p>{t('cookies.consentText')}</p>
      </section>

      <section>
        <h2 className="font-['Cormorant_Garamond'] text-2xl font-medium text-[#2C3E33] mb-4">
          {t('cookies.changesTitle')}
        </h2>
        <p>{t('cookies.changesText')}</p>
      </section>

      <section>
        <h2 className="font-['Cormorant_Garamond'] text-2xl font-medium text-[#2C3E33] mb-4">
          {t('cookies.contactTitle')}
        </h2>
        <p>{t('cookies.contactText')}</p>
      </section>
    </>
  );

  return (
    <LegalPage
      titleKey={t('cookies.title')}
      lastUpdated={t('cookies.lastUpdated')}
    >
      {content}
    </LegalPage>
  );
};

export default CookiesPage;
