import React from 'react';
import { useTranslation } from 'react-i18next';
import LegalPage from './LegalPage';

const TermsPage: React.FC = () => {
  const { t } = useTranslation();

  const content = (
    <>
      <section>
        <h2 className="font-['Cormorant_Garamond'] text-2xl font-medium text-[#2C3E33] mb-4">
          {t('terms.introTitle')}
        </h2>
        <p>{t('terms.introText')}</p>
      </section>

      <section>
        <h2 className="font-['Cormorant_Garamond'] text-2xl font-medium text-[#2C3E33] mb-4">
          {t('terms.useTitle')}
        </h2>
        <p>{t('terms.useIntro')}</p>
        <ul className="list-disc pl-6 space-y-1 mt-2">
          <li>{t('terms.use1')}</li>
          <li>{t('terms.use2')}</li>
          <li>{t('terms.use3')}</li>
          <li>{t('terms.use4')}</li>
        </ul>
      </section>

      <section>
        <h2 className="font-['Cormorant_Garamond'] text-2xl font-medium text-[#2C3E33] mb-4">
          {t('terms.intellectualTitle')}
        </h2>
        <p>{t('terms.intellectualText')}</p>
      </section>

      <section>
        <h2 className="font-['Cormorant_Garamond'] text-2xl font-medium text-[#2C3E33] mb-4">
          {t('terms.liabilityTitle')}
        </h2>
        <p>{t('terms.liabilityIntro')}</p>
        <ul className="list-disc pl-6 space-y-1 mt-2">
          <li>{t('terms.liability1')}</li>
          <li>{t('terms.liability2')}</li>
          <li>{t('terms.liability3')}</li>
        </ul>
      </section>

      <section>
        <h2 className="font-['Cormorant_Garamond'] text-2xl font-medium text-[#2C3E33] mb-4">
          {t('terms.linksTitle')}
        </h2>
        <p>{t('terms.linksText')}</p>
      </section>

      <section>
        <h2 className="font-['Cormorant_Garamond'] text-2xl font-medium text-[#2C3E33] mb-4">
          {t('terms.modificationsTitle')}
        </h2>
        <p>{t('terms.modificationsText')}</p>
      </section>

      <section>
        <h2 className="font-['Cormorant_Garamond'] text-2xl font-medium text-[#2C3E33] mb-4">
          {t('terms.governingTitle')}
        </h2>
        <p>{t('terms.governingText')}</p>
      </section>

      <section>
        <h2 className="font-['Cormorant_Garamond'] text-2xl font-medium text-[#2C3E33] mb-4">
          {t('terms.privacyTitle')}
        </h2>
        <p>{t('terms.privacyText')}</p>
      </section>

      <section>
        <h2 className="font-['Cormorant_Garamond'] text-2xl font-medium text-[#2C3E33] mb-4">
          {t('terms.contactTitle')}
        </h2>
        <p>{t('terms.contactText')}</p>
      </section>
    </>
  );

  return (
    <LegalPage
      titleKey={t('terms.title')}
      lastUpdated={t('terms.lastUpdated')}
    >
      {content}
    </LegalPage>
  );
};

export default TermsPage;
