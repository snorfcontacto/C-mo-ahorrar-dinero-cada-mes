import React from 'react';
import { useTranslation } from 'react-i18next';
import LegalPage from './LegalPage';

const PrivacyPage: React.FC = () => {
  const { t } = useTranslation();

  const content = (
    <>
      <section>
        <h2 className="font-['Cormorant_Garamond'] text-2xl font-medium text-[#2C3E33] mb-4">
          {t('privacy.introTitle')}
        </h2>
        <p>{t('privacy.introText')}</p>
      </section>

      <section>
        <h2 className="font-['Cormorant_Garamond'] text-2xl font-medium text-[#2C3E33] mb-4">
          {t('privacy.responsibleTitle')}
        </h2>
        <p>{t('privacy.responsibleText')}</p>
        <ul className="list-disc pl-6 space-y-1 mt-2">
          <li>{t('privacy.responsibleEmail')}</li>
        </ul>
      </section>

      <section>
        <h2 className="font-['Cormorant_Garamond'] text-2xl font-medium text-[#2C3E33] mb-4">
          {t('privacy.dataCollectedTitle')}
2       </h2>
        <p>{t('privacy.dataCollectedIntro')}</p>
        <ul className="list-disc pl-6 space-y-1 mt-2">
          <li>{t('privacy.dataCollected1')}</li>
          <li>{t('privacy.dataCollected2')}</li>
          <li>{t('privacy.dataCollected3')}</li>
        </ul>
      </section>

      <section>
        <h2 className="font-['Cormorant_Garamond'] text-2xl font-medium text-[#2C3E33] mb-4">
          {t('privacy.purposeTitle')}
        </h2>
        <p>{t('privacy.purposeIntro')}</p>
        <ul className="list-disc pl-6 space-y-1 mt-2">
          <li>{t('privacy.purpose1')}</li>
          <li>{t('privacy.purpose2')}</li>
          <li>{t('privacy.purpose3')}</li>
          <li>{t('privacy.purpose4')}</li>
        </ul>
      </section>

      <section>
        <h2 className="font-['Cormorant_Garamond'] text-2xl font-medium text-[#2C3E33] mb-4">
          {t('privacy.legalBasisTitle')}
        </h2>
        <p>{t('privacy.legalBasisText')}</p>
      </section>

      <section>
        <h2 className="font-['Cormorant_Garamond'] text-2xl font-medium text-[#2C3E33] mb-4">
          {t('privacy.retentionTitle')}
        </h2>
        <p>{t('privacy.retentionText')}</p>
      </section>

      <section>
        <h2 className="font-['Cormorant_Garamond'] text-2xl font-medium text-[#2C3E33] mb-4">
          {t('privacy.rightsTitle')}
        </h2>
        <p>{t('privacy.rightsIntro')}</p>
        <ul className="list-disc pl-6 space-y-1 mt-2">
          <li>{t('privacy.right1')}</li>
          <li>{t('privacy.right2')}</li>
          <li>{t('privacy.right3')}</li>
          <li>{t('privacy.right4')}</li>
          <li>{t('privacy.right5')}</li>
        </ul>
        <p className="mt-4">{t('privacy.rightsContact')}</p>
      </section>

      <section>
        <h2 className="font-['Cormorant_Garamond'] text-2xl font-medium text-[#2C3E33] mb-4">
          {t('privacy.securityTitle')}
        </h2>
        <p>{t('privacy.securityText')}</p>
      </section>

      <section>
        <h2 className="font-['Cormorant_Garamond'] text-2xl font-medium text-[#2C3E33] mb-4">
          {t('privacy.thirdPartiesTitle')}
        </h2>
        <p>{t('privacy.thirdPartiesText')}</p>
      </section>

      <section>
        <h2 className="font-['Cormorant_Garamond'] text-2xl font-medium text-[#2C3E33] mb-4">
          {t('privacy.changesTitle')}
        </h2>
        <p>{t('privacy.changesText')}</p>
      </section>

      <section>
        <h2 className="font-['Cormorant_Garamond'] text-2xl font-medium text-[#2C3E33] mb-4">
          {t('privacy.contactTitle')}
        </h2>
        <p>{t('privacy.contactText')}</p>
      </section>
    </>
  );

  return (
    <LegalPage
      titleKey={t('privacy.title')}
      lastUpdated={t('privacy.lastUpdated')}
    >
      {content}
    </LegalPage>
  );
};

export default PrivacyPage;
