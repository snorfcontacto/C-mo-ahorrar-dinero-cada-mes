import React from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router';
import { ArrowLeft, Leaf } from 'lucide-react';

interface LegalPageProps {
  titleKey: string;
  lastUpdated: string;
  children: React.ReactNode;
}

const LegalPage: React.FC<LegalPageProps> = ({ titleKey, lastUpdated, children }) => {
  const { t } = useTranslation();
  const navigate = useNavigate();

  const handleBack = () => {
    navigate('/');
  };

  const scrollToSection = (section: string) => {
    navigate('/');
    setTimeout(() => {
      const el = document.getElementById(section);
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  return (
    <div className="min-h-screen bg-[#F5F1EB]">
      {/* Header */}
      <header className="w-full bg-white/95 backdrop-blur-sm shadow-[0_2px_20px_rgba(0,0,0,0.08)]">
        <div className="max-w-[1200px] mx-auto px-5 md:px-10 py-4">
          <div className="flex items-center justify-between">
            <button
              onClick={handleBack}
              className="flex items-center gap-2 text-[#2C3E33] hover:text-[#3A6B5F] transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
              <span className="text-sm font-medium">{t('nav.home')}</span>
            </button>
            <button
              onClick={() => scrollToSection('hero')}
              className="flex items-center gap-2 group"
            >
              <Leaf className="w-6 h-6 text-[#3A6B5F]" />
              <span className="font-['Cormorant_Garamond'] text-xl font-light text-[#2C3E33]">
                Ahorra<span className="font-medium">Inteligente</span>
              </span>
            </button>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="py-12 md:py-20">
        <div className="max-w-[800px] mx-auto px-5 md:px-10">
          <p className="text-xs font-medium uppercase tracking-[0.12em] text-[#3A6B5F] mb-3">
            {lastUpdated}
          </p>
          <h1 className="font-['Cormorant_Garamond'] text-3xl md:text-4xl lg:text-5xl font-normal leading-[1.15] tracking-[-0.01em] text-[#2C3E33] mb-10">
            {titleKey}
          </h1>
          <div className="prose prose-lg max-w-none text-[#2C3E33]/80 leading-relaxed space-y-6">
            {children}
          </div>
        </div>
      </main>
    </div>
  );
};

export default LegalPage;
